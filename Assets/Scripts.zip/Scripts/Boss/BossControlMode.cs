public enum BossControlMode
{
    AI,
    Player
}
