public enum GameState
{
    Playing,
    BossWin,
    WorkerWin
}
