[System.Serializable]
public class GameResult
{
    public bool bossWin;
    public int eliminatedWorkers;
    // 员工相关
    public int destroyedMachines;

    // 老板相关
    public int totalCatches;
}
