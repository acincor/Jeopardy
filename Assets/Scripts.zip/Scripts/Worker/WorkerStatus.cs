public enum WorkerLifeState
{
    Alive,
    Downed,
    Eliminated
}
public enum WorkerState
{
    Idle,
    Destroying,
    Evading,
    Caught
}
